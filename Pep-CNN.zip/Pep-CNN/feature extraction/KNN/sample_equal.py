def loadDatadet(infile):
    f=open(infile,'r')
    sourceInLine=f.readlines()
    dataset=[]
    for line in sourceInLine:
        temp1=line.strip('\n')
        temp2=temp1.split('\t')
        dataset.append(temp2)
    return dataset
infile='F:\python\KNN\AAP.txt'
infile=loadDatadet(infile)
for i in infile:
    while len(i) <= max(len(infile(i))):
        i = i + '0'
        print(i)